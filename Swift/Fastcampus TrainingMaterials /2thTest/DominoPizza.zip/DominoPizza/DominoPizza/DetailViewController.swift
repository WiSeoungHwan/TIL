//
//  DetailViewController.swift
//  DominoPizza
//
//  Created by Kira on 18/04/2019.
//  Copyright © 2019 Kira. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
    }
    
    
}
