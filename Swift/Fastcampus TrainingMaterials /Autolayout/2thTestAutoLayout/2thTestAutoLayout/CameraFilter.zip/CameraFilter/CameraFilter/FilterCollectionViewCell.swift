//
//  FilterCollectionViewCell.swift
//  CameraFilter
//
//  Created by Fury on 09/05/2019.
//  Copyright © 2019 Fury. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    
    static let identifier = "FilterCollectionViewCell"
    
    let filterImage: UIImageView = {
        let filterImage = UIImageView()
        filterImage.translatesAutoresizingMaskIntoConstraints = false
        return filterImage
    }()
    
    let filterName: UILabel = {
        let filterName = UILabel()
        filterName.translatesAutoresizingMaskIntoConstraints = false
        return filterName
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addContentView()
        autoLayout()
    }
    
    private func addContentView() {
        filterName.backgroundColor = .red
        filterImage.backgroundColor = .blue
        contentView.addSubview(filterImage)
        contentView.addSubview(filterName)
    }
    
    private func autoLayout() {
        let margin: CGFloat = 5
        NSLayoutConstraint.activate([
            filterImage.topAnchor.constraint(equalTo: self.topAnchor),
            filterImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: margin),
            filterImage.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -margin),
            
            filterName.topAnchor.constraint(equalTo: filterImage.bottomAnchor),
            filterName.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: margin),
            filterName.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -margin),
            filterName.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            filterName.heightAnchor.constraint(equalTo: filterImage.heightAnchor, multiplier: 0.2),
            ])
    }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
