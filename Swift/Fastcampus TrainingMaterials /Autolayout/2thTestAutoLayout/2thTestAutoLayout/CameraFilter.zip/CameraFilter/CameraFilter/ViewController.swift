//
//  ViewController.swift
//  CameraFilter
//
//  Created by Fury on 09/05/2019.
//  Copyright © 2019 Fury. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    private let picker = UIImagePickerController()
    
    private let filterList: FilterView = {
        let filterList = FilterView()
        filterList.translatesAutoresizingMaskIntoConstraints = false
        return filterList
    }()
    
    private let displayImage: UIImageView = {
        let displayImage = UIImageView()
        displayImage.contentMode = .scaleAspectFit
        displayImage.translatesAutoresizingMaskIntoConstraints = false
        return displayImage
    }()
    
    private let bottomView: UIView = {
        let bottomView = UIView()
        bottomView.translatesAutoresizingMaskIntoConstraints = false
        return bottomView
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configuration()
        addSubView()
        autolayout()
    }
    
    private func alertSheet() {
        let alert = UIAlertController(title: "선택", message: "선택하세요.", preferredStyle: .actionSheet)
        
        let photoLibrary = UIAlertAction(title: "라이브러리", style: .default) { _ in
            self.picker.sourceType = .photoLibrary
            self.present(self.picker, animated: true)
            
        }
        
        let camera = UIAlertAction(title: "카메라", style: .default) { _ in
            self.picker.sourceType = .camera
            self.present(self.picker, animated: true)
        }
        
        let savedPhotosAlbum = UIAlertAction(title: "앨범", style: .default) { _ in
            self.picker.sourceType = .savedPhotosAlbum
            self.present(self.picker, animated: true)
        }
        
        let cancel = UIAlertAction(title: "취소", style: .cancel)
        
        alert.addAction(photoLibrary)
        alert.addAction(camera)
        alert.addAction(savedPhotosAlbum)
        alert.addAction(cancel)
        
        self.present(alert, animated: true)
    }
    
    private func configuration() {
        
        self.displayImage.image = UIImage(named: "123")
        self.view.backgroundColor = .black
        picker.delegate = self
        filterList.delegate = self
    }
    
    private func addSubView() {
        view.addSubview(displayImage)
        view.addSubview(bottomView)
        bottomView.addSubview(filterList)
    }
    
    private func autolayout() {
        let guide = view.safeAreaLayoutGuide
        let margin: CGFloat = 20
        NSLayoutConstraint.activate([
            displayImage.centerXAnchor.constraint(equalTo: guide.centerXAnchor),
            displayImage.centerYAnchor.constraint(equalTo: guide.centerYAnchor, constant: -margin * 4),
            displayImage.widthAnchor.constraint(equalTo: guide.widthAnchor),
            displayImage.heightAnchor.constraint(equalToConstant: 300),
            
            bottomView.leadingAnchor.constraint(equalTo: guide.leadingAnchor),
            bottomView.trailingAnchor.constraint(equalTo: guide.trailingAnchor),
            bottomView.bottomAnchor.constraint(equalTo: guide.bottomAnchor),
            bottomView.heightAnchor.constraint(equalToConstant: 120),
            
            filterList.topAnchor.constraint(equalTo: bottomView.topAnchor),
            filterList.leadingAnchor.constraint(equalTo: bottomView.leadingAnchor),
            filterList.trailingAnchor.constraint(equalTo: bottomView.trailingAnchor),
            filterList.bottomAnchor.constraint(equalTo: bottomView.bottomAnchor),
            ])
    }
    
    
}

extension ViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let originalImage = info[.originalImage] as! UIImage
        displayImage.image = originalImage
        picker.dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("[ imagePickerControllerDidCancel ]")
        
    }
}

extension ViewController: FilterViewDelegate {
    func changeDisplayPicture() {
        alertSheet()
    }
}
