//
//  FilterView.swift
//  CameraFilter
//
//  Created by Fury on 09/05/2019.
//  Copyright © 2019 Fury. All rights reserved.
//

import UIKit

protocol FilterViewDelegate: class {
    func changeDisplayPicture() -> Void
}

class FilterView: UIView {
    
//    private let filter = Filter()
    private var FilterColors: [UIColor] = []
    private var buttons = [UIButton]()
    
    let layout = UICollectionViewFlowLayout()

    weak var delegate: FilterViewDelegate?
    
    private let filters: UICollectionView = {
        let filters = UICollectionView(frame: CGRect.zero, collectionViewLayout: UICollectionViewLayout())
        filters.backgroundColor = .green
        
        filters.translatesAutoresizingMaskIntoConstraints = false
        return filters
    }()
    
    private let cameraButton: UIButton = {
        let cameraButton = UIButton()
        cameraButton.setBackgroundImage(UIImage(named: "camera"), for: .normal)
        cameraButton.contentMode = .scaleAspectFit
        cameraButton.addTarget(self, action: #selector(didTapCameraButton(_:)), for: .touchUpInside)
        cameraButton.translatesAutoresizingMaskIntoConstraints = false
        return cameraButton
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubView()
        configure()
        autoLayout()
    }
    
    @objc private func didTapCameraButton(_ sender: UIButton) {
        delegate?.changeDisplayPicture()
    }
    
    private func configure() {

        filters.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: FilterCollectionViewCell.identifier)
        filters.dataSource = self
    }
    
    private func addSubView() {
        self.addSubview(filters)
        self.addSubview(cameraButton)
    }
    
    private func autoLayout() {
        NSLayoutConstraint.activate([
            filters.topAnchor.constraint(equalTo: self.topAnchor),
            filters.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            filters.trailingAnchor.constraint(equalTo: self.trailingAnchor),
            
            cameraButton.topAnchor.constraint(equalTo: self.filters.bottomAnchor),
            cameraButton.leadingAnchor.constraint(equalTo: self.leadingAnchor),
            cameraButton.bottomAnchor.constraint(equalTo: self.bottomAnchor),
            cameraButton.widthAnchor.constraint(equalToConstant: 60),
            cameraButton.heightAnchor.constraint(equalTo: filters.heightAnchor),
            ])
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension FilterView: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: FilterCollectionViewCell.identifier, for: indexPath) as! FilterCollectionViewCell
        cell.filterImage.image = UIImage(named: "camera")
        cell.filterName.text = "\(indexPath.row + 1)"
        return cell
    }
}
extension FilterView: UICollectionViewDelegateFlowLayout{
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: self.frame.width / 3, height: 100)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets{
        
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat{
        
        return 0
    }
    
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat{
        
        return 0
    }
}
