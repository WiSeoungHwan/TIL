//
//  Filter.swift
//  CameraFilter
//
//  Created by Fury on 09/05/2019.
//  Copyright © 2019 Fury. All rights reserved.
//

import UIKit

struct Filter {
    let colors: [UIColor] = [
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
        UIColor(hue: 0.5, saturation: 0.5, brightness: 0.5, alpha: 0.3),
    ]
}
