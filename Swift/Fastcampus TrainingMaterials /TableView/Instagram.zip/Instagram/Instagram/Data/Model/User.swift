//
//  User.swift
//  Instagram
//
//  Created by Wi on 04/05/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import Foundation
import UIKit

struct User{
    var userName: String
    var profileImage: UIImage?
}
