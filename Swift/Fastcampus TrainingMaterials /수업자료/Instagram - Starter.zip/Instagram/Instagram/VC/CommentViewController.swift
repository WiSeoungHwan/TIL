//
//  CommentViewController.swift
//  Instagram
//
//  Created by Wi on 23/04/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit

// HomeVC에서 보여주는 FeedData에서 댓글 버튼을 누르면 나올 컨트롤러입니다.
// 각각의 FeedData 에 각각의 댓글을 보여줍니다.
// 이모티콘 버튼은 선택사항입니다.

class CommentViewController: UIViewController{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
