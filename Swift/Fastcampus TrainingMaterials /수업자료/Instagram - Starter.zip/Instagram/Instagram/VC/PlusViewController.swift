//
//  PlusViewController.swift
//  Instagram
//
//  Created by Wi on 12/04/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit

// 실제로 사용되진 않지만 탭바에 한자리를 차지할 컨트롤러입니다.
// plus 탭을 탭하면 photo앨범 화면을 띄웁니다.

class PlusViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

}
