//
//  MyViewController.swift
//  Instagram
//
//  Created by Wi on 03/05/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit


// 닉네임과 프로필 이미지를 변경하게 될 컨트롤러 입니다.
// 여기서 닉네임과 프로필 이미지를 변경한 다음 부터는 피드를 추가할때 등록된 닉네임과 프로필 이미지로 피드가 등록되어야 합니다.
// 닉네임 중복검사는 선택사항입니다. 
// 기본 값이 UITableViewController 입니다. 기본 뷰컨트롤러로 구현하고 싶으시면 타입을 UIViewController로 바꿔주세요.

class MyViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
}
