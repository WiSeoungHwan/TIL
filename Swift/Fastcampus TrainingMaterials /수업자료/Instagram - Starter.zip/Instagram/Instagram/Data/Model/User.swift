//
//  User.swift
//  Instagram
//
//  Created by Wi on 04/05/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import Foundation
import UIKit

// user 데이터를 만들어보세요.
// user가 가지고 있을 데이터가 무엇인지 생각해보세요.
struct User{

}
