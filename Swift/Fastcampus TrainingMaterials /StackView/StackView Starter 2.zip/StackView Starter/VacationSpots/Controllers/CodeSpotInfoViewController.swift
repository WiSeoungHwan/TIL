//
//  CodeSpotInfoViewController.swift
//  VacationSpots
//
//  Created by Wi on 29/05/2019.
//  Copyright © 2019 Jawwad Ahmad. All rights reserved.
//

import UIKit

class CodeSpotInfoViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
