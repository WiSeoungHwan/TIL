//
//  NormalLoadingViewController.swift
//  Kingfisher-Demo
//
//  Created by Wei Wang on 15/4/6.
//
//  Copyright (c) 2019 Wei Wang <onevcat@gmail.com>
//
//  Permission is hereby granted, free of charge, to any person obtaining a copy
//  of this software and associated documentation files (the "Software"), to deal
//  in the Software without restriction, including without limitation the rights
//  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//  copies of the Software, and to permit persons to whom the Software is
//  furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
//  THE SOFTWARE.

import UIKit
import Kingfisher

class NormalLoadingViewController: UICollectionViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Loading"
        setupOperationNavigationBar()
        collectionView?.prefetchDataSource = self
    }
}

extension NormalLoadingViewController {
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // 예제 이미지 URL
        return ImageLoader.sampleImageURLs.count
    }
    
    override func collectionView(
        _ collectionView: UICollectionView,
        didEndDisplaying cell: UICollectionViewCell,
        forItemAt indexPath: IndexPath)
    {
        // This will cancel all unfinished downloading task when the cell disappearing.
        // 셀이 보여지지 않을때 완료되지 않은 모든 다운로드 작업 취소
        (cell as! ImageCollectionViewCell).cellImageView.kf.cancelDownloadTask()
    }
    
    override func collectionView(
        _ collectionView: UICollectionView,
        willDisplay cell: UICollectionViewCell,
        forItemAt indexPath: IndexPath)
    {
        // 셀이 보여지기 전에
        // 만들어준 커스텀 셀의 이미지뷰를 불러온다.
        let imageView = (cell as! ImageCollectionViewCell).cellImageView!
        // 일반적으로 쓰는 가장 흔한 방법
        imageView.kf.setImage(
            with: ImageLoader.sampleImageURLs[indexPath.row], // url 넣기
            placeholder: nil, // 이미지가 보여지기전 사진 넣기
            // 옵션들 이미지 보여지는 방식이나 캐시 방식 정할 수 있음
            // .loadDiskFileSynchronously: 로딩 성능의 균형을 맞추어 깜박임을 없앤다.
            options: [.transition(.fade(1)), .loadDiskFileSynchronously],
            // 진행률이 업데이트 될때 마다 호출 되는 메서드
            // response에 예상 콘텐츠 길이가 포함되어 있지 않으면 호출되지 않음.
            // progressBlock은 서버 응답에 헤더에 "Content-Length"가 포함 된 경우에만 호출됩니다.
            progressBlock: { receivedSize, totalSize in
//                print("****\(indexPath.row + 1): \(receivedSize)/\(totalSize)")
//                이미지 퍼센테이지 호출하는법
                let percentage = (Float(receivedSize) / Float(totalSize)) * 100.0
                print("\(indexPath.row + 1)번째 이미지: downloading progress: \(percentage)%")
            },
            // 완료 블럭 완료된 시점에 호출됨.
            completionHandler: { result in
                print(result)
                print("\(indexPath.row + 1): Finished")
            }
        )
        
    }
    
    override func collectionView(
        _ collectionView: UICollectionView,
        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(
            withReuseIdentifier: "collectionViewCell",
            for: indexPath) as! ImageCollectionViewCell
        // 인디케이터 타입 정하기
        cell.cellImageView.kf.indicatorType = .activity
        // 인디케이터 없애기
//        cell.cellImageView.kf.indicatorType = .none
        // 인디케이터 gif 파일 넣기
//        let path = Bundle.main.path(forResource: "loader", ofType: "gif")!
//        let data = try! Data(contentsOf: URL(fileURLWithPath: path))
//
//        imageView.kf.indicatorType = .image(imageData: data)
        // 인디케이터 custom
        
        return cell
    }
}

extension NormalLoadingViewController: UICollectionViewDataSourcePrefetching {
    func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath]) {
        let urls = indexPaths.compactMap { ImageLoader.sampleImageURLs[$0.row] }
        ImagePrefetcher(urls: urls).start()
    }
}
