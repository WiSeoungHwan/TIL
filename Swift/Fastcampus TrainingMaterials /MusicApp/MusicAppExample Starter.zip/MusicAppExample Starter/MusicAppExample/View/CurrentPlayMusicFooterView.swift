//
//  CurrentPlayMusicFooterView.swift
//  URLSessionPractice
//
//  Created by Wi on 11/06/2019.
//  Copyright © 2019 Wi. All rights reserved.
//

import UIKit

class CurrentPlayMusicFooterView: UITableViewHeaderFooterView {
    
    
}
